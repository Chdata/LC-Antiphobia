# LC-Antiphobia
 Chdata's Antiphobia Mod for Lethal Company

# Features:
- Fixed Arachnophobia Mode (Removes the spider's fangs floating with the text)
- Trypophobia Mode (Fear or disgust of a pattern of holes - replaced texture on Circuit Beehive)

# Installation Instructions
Use your favorite mod manager to install!

You MUST set `HideManagerGameObject = true` in your `BepInEx/config/BepInEx.cfg` file for the sound replacements to work!

Remember your mod manager can open that config in the Config Editor!

The "antiphobia.assetbundle" file belongs in the same folder as "Antiphobia.dll". It contains the model and sounds.

# Contact
You can find me on the Lethal Company Modding Discord. https://discord.com/channels/1168655651455639582/1187139195387523185

Twitter: https://twitter.com/Chdata

# Planned Features:
- Hoplophobia Mode (Fear of firearms)
- ~~Melissophobia Mode (Fear of bees)~~
- Cynophobia Mode (Fear of dogs)
- Ornithophobia Mode (Fear of birds)

I plan to develop this to a certain point that will hopefully work without needing too much maintenance, and then move on to other projects.

# FAQ:
Q. Will you add X phobia mode?
A. Tell me about it on Discord in the unofficial Lethal Company modding community, and I will consider it.

But I will not guarantee it, because I work full time.

Q. Why no Melissophobia Mode?
A. I wanted add it, but I couldn't figure out how to change the bee's graphics through mods.

# Known Bugs:
- I removed the Bunker Spider's fangs outside of Arachnophobia Mode too.

# Credits
Thanks to the Lethal Company Modding Discord for teaching me the ropes!
https://discord.gg/v5t3KkEdsv
